# local_innealla_enrol

Sync students and staff enrolments from SIS.

Requires `local_innealla`. Gated by SIS Integration Hub feature flags.
