# local_innealla_suspend

Suspend Moodle accounts flagged by SIS.

Requires `local_innealla`. Gated by SIS Integration Hub feature flags.
