# local_innealla_dates

Sync assessment due dates onto grade items.

Requires `local_innealla`. Gated by SIS Integration Hub feature flags.
