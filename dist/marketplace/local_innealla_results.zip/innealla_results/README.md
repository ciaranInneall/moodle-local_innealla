# local_innealla_results

Push official released marks from SIS into Moodle.

Requires `local_innealla`. Gated by SIS Integration Hub feature flags.
