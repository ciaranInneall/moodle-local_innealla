# local_innealla_categories

Build programme/year course category tree.

Requires `local_innealla`. Gated by SIS Integration Hub feature flags.
