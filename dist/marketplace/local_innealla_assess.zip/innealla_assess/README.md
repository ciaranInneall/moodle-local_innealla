# local_innealla_assess

Create Moodle grade items from SIS assessments.

Requires `local_innealla`. Gated by SIS Integration Hub feature flags.
