# local_innealla_courses

Create/update Moodle courses from SIS module deliveries.

Requires `local_innealla`. Gated by SIS Integration Hub feature flags.
